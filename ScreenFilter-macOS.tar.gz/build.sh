#!/bin/bash

# Screen Filter - Build Script for macOS
# This script helps build the Screen Filter app on macOS

set -e

echo "🎨 Screen Filter - Build Script"
echo "================================"
echo ""

# Check if we're on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "❌ Error: This script must be run on macOS"
    exit 1
fi

# Check if Swift is available
if ! command -v swift &> /dev/null; then
    echo "❌ Error: Swift is not installed"
    echo "Please install Xcode from the App Store"
    exit 1
fi

echo "✅ Swift detected: $(swift --version | head -n 1)"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
APP_DIR="$SCRIPT_DIR/ScreenFilter.app"

# Check if app bundle exists
if [ ! -d "$APP_DIR" ]; then
    echo "❌ Error: ScreenFilter.app directory not found"
    exit 1
fi

echo "📦 Building Screen Filter..."
echo ""

# Make sure the executable is executable
EXECUTABLE="$APP_DIR/Contents/MacOS/ScreenFilter"
if [ -f "$EXECUTABLE" ]; then
    chmod +x "$EXECUTABLE"
    echo "✅ Made executable: $EXECUTABLE"
else
    echo "❌ Error: Executable not found at $EXECUTABLE"
    exit 1
fi

# Check if the Swift file can be parsed
echo "🔍 Validating Swift code..."
if head -n 1 "$EXECUTABLE" | grep -q "#!/usr/bin/env swift"; then
    echo "✅ Swift script header found"
else
    echo "⚠️  Warning: Swift script header missing"
fi

echo ""
echo "================================"
echo "✅ Build complete!"
echo ""
echo "📍 App location: $APP_DIR"
echo ""
echo "To install:"
echo "  1. Copy ScreenFilter.app to /Applications"
echo "  2. Open from Finder or run: open '$APP_DIR'"
echo ""
echo "To run directly:"
echo "  '$EXECUTABLE'"
echo ""
echo "If macOS blocks the app:"
echo "  1. Go to System Preferences → Security & Privacy"
echo "  2. Click 'Open Anyway' next to Screen Filter"
echo "  3. Or right-click the app → Open → Open"
echo ""
echo "Enjoy! 🎨"
